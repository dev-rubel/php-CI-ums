     <!-- end row -->
        </div>
        <!-- END container-fluid -->
    </div>
    <!-- END content -->
</div>
<footer class="footer text-center">
    <span class="text-center">
        Copyright <a target="_blank" href="#">Dhaka International University</a>
    </span>
</footer>
</div>

    
    <script src="<?php echo base_url();?>assets/js/modernizr.min.js"></script>
    <script src="<?php //echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/detect.js"></script>
    <script src="<?php echo base_url();?>assets/js/fastclick.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.blockUI.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.nicescroll.js"></script>
    <!-- App js -->
    <script src="<?php echo base_url();?>assets/js/pikeadmin.js"></script>
    <!-- BEGIN Java Script for this page -->
    <!-- Counter-Up-->
    <script src="<?php echo base_url();?>assets/plugins/waypoints/lib/jquery.waypoints.min.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/counterup/jquery.counterup.min.js"></script>
    
    <script>
    
    $(document).ready(function() {
    // counter-up
    $('.counter').counterUp({
    delay: 10,
    time: 600
    });
    });
    </script>
    <!-- END Java Script for this page -->
    </body>
</html>