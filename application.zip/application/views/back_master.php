<?php echo $header; ?>
<!-- Left Sidebar -->
<?php echo $sidebar; ?>
<!-- End Sidebar -->
<?php echo $content; ?>
<!-- END content-page -->
<?php echo $footer; ?>